-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema gm_libreoffice
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema gm_libreoffice
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `gm_libreoffice` DEFAULT CHARACTER SET latin1 ;
USE `gm_libreoffice` ;

-- -----------------------------------------------------
-- Table `gm_libreoffice`.`t_people`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gm_libreoffice`.`t_people` (
  `id` INT(11) NULL,
  `p_accountId` VARCHAR(16) NOT NULL,
  `p_name` VARCHAR(64) NULL DEFAULT NULL,
  `p_email` VARCHAR(64) NULL DEFAULT NULL,
  `p_userName` VARCHAR(64) NULL DEFAULT NULL,
  PRIMARY KEY (`p_accountId`))
ENGINE = InnoDB
AUTO_INCREMENT = 635
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gm_libreoffice`.`t_change`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gm_libreoffice`.`t_change` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `ch_id` VARCHAR(256) NULL DEFAULT NULL,
  `ch_changeId` VARCHAR(64) NULL,
  `ch_changeIdNum` INT(11) NULL DEFAULT NULL,
  `ch_project` VARCHAR(128) NULL DEFAULT NULL,
  `ch_branch` VARCHAR(128) NULL DEFAULT NULL,
  `ch_topic` VARCHAR(128) NULL DEFAULT NULL,
  `ch_authorAccountId` VARCHAR(16) NULL,
  `ch_createdTime` DATETIME NULL DEFAULT NULL,
  `ch_updatedTime` DATETIME NULL DEFAULT NULL,
  `ch_status` VARCHAR(16) NULL DEFAULT NULL,
  `ch_mergeable` VARCHAR(16) NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_t_change_1_idx` (`ch_authorAccountId` ASC),
  CONSTRAINT `fk_t_change_1`
    FOREIGN KEY (`ch_authorAccountId`)
    REFERENCES `gm_libreoffice`.`t_people` (`p_accountId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 28031
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gm_libreoffice`.`t_revision`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gm_libreoffice`.`t_revision` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `rev_id` VARCHAR(64) NULL DEFAULT NULL,
  `rev_subject` LONGTEXT NULL DEFAULT NULL,
  `rev_message` LONGTEXT NULL DEFAULT NULL,
  `rev_authorUsername` VARCHAR(64) NULL DEFAULT NULL,
  `rev_createdTime` DATETIME NULL DEFAULT NULL,
  `rev_committerUsername` VARCHAR(64) NULL DEFAULT NULL,
  `rev_committedTime` DATETIME NULL DEFAULT NULL,
  `rev_ref` VARCHAR(256) NULL DEFAULT NULL,
  `rev_git` VARCHAR(256) NULL DEFAULT NULL,
  `rev_repo` VARCHAR(256) NULL DEFAULT NULL,
  `rev_http` VARCHAR(256) NULL DEFAULT NULL,
  `rev_ssh` VARCHAR(256) NULL DEFAULT NULL,
  `rev_patchSetNum` INT(11) NULL,
  `rev_changeId` INT(11) NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_t_revision_1_idx` (`rev_changeId` ASC),
  CONSTRAINT `fk_t_revision_1`
    FOREIGN KEY (`rev_changeId`)
    REFERENCES `gm_libreoffice`.`t_change` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 70763
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gm_libreoffice`.`t_file`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gm_libreoffice`.`t_file` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `f_fileName` VARCHAR(512) NULL DEFAULT NULL,
  `f_linesInserted` INT(11) NULL DEFAULT NULL,
  `f_linesDeleted` INT(11) NULL DEFAULT NULL,
  `f_revisionId` INT(11) NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `fk_t_file_1`
    FOREIGN KEY (`f_revisionId`)
    REFERENCES `gm_libreoffice`.`t_revision` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 1000295
DEFAULT CHARACTER SET = utf8;


-- -----------------------------------------------------
-- Table `gm_libreoffice`.`t_history`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `gm_libreoffice`.`t_history` (
  `id` INT(11) NOT NULL AUTO_INCREMENT,
  `hist_id` VARCHAR(64) NULL DEFAULT NULL,
  `hist_message` LONGTEXT NULL DEFAULT NULL,
  `hist_authorAccountId` VARCHAR(16) NULL,
  `hist_createdTime` DATETIME NULL DEFAULT NULL,
  `hist_patchSetNum` INT(11) NULL,
  `hist_changeId` INT(11) NULL,
  PRIMARY KEY (`id`),
  INDEX `hist_changeId` (`hist_changeId` ASC),
  INDEX `fk_t_history_2_idx` (`hist_authorAccountId` ASC),
  CONSTRAINT `fk_t_history_1`
    FOREIGN KEY (`hist_changeId`)
    REFERENCES `gm_libreoffice`.`t_change` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_t_history_2`
    FOREIGN KEY (`hist_authorAccountId`)
    REFERENCES `gm_libreoffice`.`t_people` (`p_accountId`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 174182
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
